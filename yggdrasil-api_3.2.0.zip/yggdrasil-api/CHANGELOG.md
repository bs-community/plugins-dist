# 更新日志

## v3.2.0

- 修复可能导致无法识别皮肤地址的问题
- 修复「关闭日志输出」选项未起作用的问题

## v3.0.0

- 完成对 Blessing Skin v4.0.0 的支持和适配（不再支持 BS v3 及以下版本）
- 进一步地完善对 Yggdrasil API 规范的实现
- 移除了「导入 UUID 映射」的功能
- 移除了「显示近期活动」的功能

## v3.0.0-beta.0
- 支持 Blessing Skin v4.0.0

## v2.1.10
- 支持 API 地址指示 (ALI) [#18](https://github.com/yushijinhun/authlib-injector/issues/18)
- 支持在元数据中包含验证服务器网址 [#25](https://github.com/yushijinhun/authlib-injector/issues/25)
- 不再向用户展示 `hasJoined` 请求的来源 IP

## v2.1.9
- 修复可能的 XSS 漏洞

## v2.1.8
- 阻止被封禁的用户使用未过期的 Access Token 进入服务器

## v2.1.7
- 修复用户修改角色名后 UUID 改变的问题 [#9](https://github.com/bs-community/blessing-skin-plugins/issues/9)（可能造成游戏内玩家数据重置）
- 选择「与离线模式一致」的 UUID 生成算法时，角色名修改后 UUID 依然会改变

## v2.1.6
- 支持最新版 BS 中的邮箱验证机制
- 未验证邮箱的用户无法通过 Yggdrasil API 登录

## v2.1.5
- 修复 FireFox 下「拖拽添加 Yggdrasil 认证服务器」不工作的问题
- 将用户中心首页的「外置登录系统 - 最近活动」板块标题更改为「你的近期活动」
- 修复与「邮箱验证插件」不兼容的问题

## v2.1.4
- 记录活动日志（`登录认证`、`进入服务器` 等）至数据库 `ygg_log` 表
- 管理后台新增「外置登录系统活动日志」查看页面
- 用户中心首页添加「最近活动」板块（可在插件配置页关闭）
- 修复某些情况下 DnD 拖拽添加 Yggdrasil 认证服务器不工作的问题
- 修复玩家进服验证相关的安全问题

## v2.1.3
- 修复 `/authserver/validate` 错误的返回值导致启动器无法刷新令牌的问题
- 修复 `/authserver/authenticate` 与 `/authserver/signout` 请求频率限制失效的问题
- 修复 `/api/profiles/minecraft` 不能正确处理重复的查询的问题
- 修复签到后用户中心「快速配置启动器」板块消失的问题
- 修复默认的令牌过期时间过短的问题
- 不再推荐普通用户使用「导入服务器 `usercache.json`」功能
- 未指定 `unsigned` 参数请求玩家 profile 时响应不再默认包含数据签名
- 添加 Parcel 前端构建流程

## v2.1.2
- 用户中心首页新增「快速配置启动器」板块（可在插件配置页关闭）
- 支持 [DnD 拖拽方式添加 Yggdrasil 认证服务器](http://t.cn/RdKTDAz)

## v2.1.1
- 初次使用时自动生成私钥
- 在插件配置页显示当前站点的 API Root
- 将 `uuid_algorithm` 配置项重命名为 `ygg_uuid_algorithm`

## v2.1.0
- 新增「一键生成私钥」的功能
- 新增「修改 UUID 生成算法」的选项，可改为与 MC 盗版用户 UUID 生成算法一致
- 新增「导入 MC 服务器 UUID 映射表（`usercache.json`）」的功能
- 增强兼容性，减少原盗版服迁移至本方案后出现 UUID 冲突的可能性，详见 http://t.cn/RrAK4F8

## v2.0.2
- 修复了用户邮箱大小写敏感的问题
- 上述问题可能导致某些用户无法进入游戏，提示「未查找到有效的登录信息，请重新登录」

## v2.0.1
- 单独记录本插件的日志到 `storage/logs/yggdrasil.log` 文件中
- 加入了超级详细的日志，几乎每个操作都有日志记录，详细到弱智都能 DEBUG
- 所以注意生产环境不要开启插件配置中的「记录详细日志」选项哦
- 修复批量查找 profile 的问题（citizens 等 NPC 插件会用到这个）
- 强制使用后台中填写的「站点地址」生成材质 URL（避免 BungeeCord 上的奇葩问题）
- 现在「插件设置」中你只需要填写私钥即可，公钥会根据私钥自动生成

## v2.0.0
- 重构插件，支持 authlib-injector
- 注意，此版本以后不再支持 authlib-agent

## v1.1.4
- 加入「记录详细日志」的选项

## v1.1.3
- 加入中文翻译
- 禁止被主站封禁的角色通过 Yggdrasil API 认证

## v1.1.1
- 添加材质的数字签名支持
- 修复一些 BUG

## v1.1.0
- 当用户只有一个角色时自动使用该角色登录

## v1.0.0
- 最初版本
