blessing.i18n.examplePlugin = {
  test: 'JavaScript i18n test: 简体中文'
}
