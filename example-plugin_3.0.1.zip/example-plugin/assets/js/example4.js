'use strict'

console.warn('示例：我将被最先加载，因为我优先级最高')
