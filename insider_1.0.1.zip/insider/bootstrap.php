<?php

return function () {
    config([
        'app.update_source' => 'https://dev.azure.com/blessing-skin/51010f6d-9f99-40f1-a262-0a67f788df32/'.
        '_apis/git/repositories/a9ff8df7-6dc3-4ff8-bb22-4871d3a43936/Items?path=%2Fupdate_preview.json'
    ]);
};
