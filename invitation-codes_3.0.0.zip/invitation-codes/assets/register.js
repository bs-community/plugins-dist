blessing.event.on('mounted', () => {
    const div = document.createElement('div');
    div.className = 'input-group mb-3';
    div.innerHTML = `
    <input
      type="text"
      required
      class="form-control"
      placeholder="邀请码"
      id="invitation-code"
    >
    <div class="input-group-append">
      <div class="input-group-text">
        <i class="fas fa-receipt"></i>
      </div>
    </div>
  `;
    setTimeout(() => {
        var _a;
        (_a = document.querySelector('.input-group:nth-child(4)')) === null || _a === void 0 ? void 0 : _a.after(div);
    }, 0);
});
// 插入邀请码的值
blessing.event.on('beforeFetch', (request) => {
    var _a;
    request.data.invitationCode =
        ((_a = document.querySelector('#invitation-code')) === null || _a === void 0 ? void 0 : _a.value) || '';
});
