<?php

return function () {
    config(['database.redis.client' => 'predis']);
};
