# Yggdrasil API for Blessing Skin

This plugin implements [Yggdrasil API Spec](https://github.com/yushijinhun/authlib-injector/wiki/Yggdrasil%20%E6%9C%8D%E5%8A%A1%E7%AB%AF%E6%8A%80%E6%9C%AF%E8%A7%84%E8%8C%83). It can be used with [authlib-injector](https://github.com/yushijinhun/authlib-injector).

## Usage

Read [documentation](https://blessing.netlify.app/yggdrasil-api/).
