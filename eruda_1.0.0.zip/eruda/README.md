Eruda 是一个开源的专为手机网页前端设计的调试面板，类似 DevTools 的迷你版，其主要功能包括：捕获 Console 日志、检查元素状态、捕获 XHR 请求、显示本地存储和 Cookie 信息等等。GitHub 项目地址：[https://github.com/liriliri/eruda](https://github.com/liriliri/eruda)

这个插件可以从 jsDelivr 加载 Eruda 主体，以便在移动端进行调试，但未为 Eruda 加载任何插件。

访问皮肤站时，在 URL 中加上 `eruda` 参数即可使用。