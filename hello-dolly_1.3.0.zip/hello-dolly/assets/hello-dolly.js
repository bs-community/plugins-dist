var _a;
{
    const lyrics = `Hello, Dolly
Well, hello, Dolly
It's so nice to have you back where you belong
You're lookin' swell, Dolly
I can tell, Dolly
You're still glowin', you're still crowin'
You're still goin' strong
We feel the room swayin'
While the band's playin'
One of your old favourite songs from way back when
So, take her wrap, fellas
Find her an empty lap, fellas
Dolly'll never go away again
Hello, Dolly
Well, hello, Dolly
It's so nice to have you back where you belong
You're lookin' swell, Dolly
I can tell, Dolly
You're still glowin', you're still crowin'
You're still goin' strong
We feel the room swayin'
While the band's playin'
One of your old favourite songs from way back when
Golly, gee, fellas
Find her a vacant knee, fellas
Dolly'll never go away
Dolly'll never go away
Dolly'll never go away again`.split('\n');
    const length = lyrics.length;
    const hitokoto = document.createElement('div');
    hitokoto.style.marginTop = '3px';
    hitokoto.textContent = lyrics[Math.floor(Math.random() * length)];
    const container = document.querySelector('.breadcrumb');
    if (container) {
        container.appendChild(hitokoto);
    }
    else {
        const container = document.createElement('div');
        container.className = 'breadcrumb';
        container.appendChild(hitokoto);
        (_a = document.querySelector('.content-header')) === null || _a === void 0 ? void 0 : _a.appendChild(container);
    }
}
