var _a;
(_a = document.querySelector('#update-uuid')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', async () => {
    const { code, message, } = await blessing.fetch.post('/mojang/update-uuid');
    const { toast } = blessing.notify;
    if (code === 0) {
        toast.success(message);
    }
    else {
        toast.error(message);
    }
});
