blessing.event.on('mounted', () => {
    var _a;
    const callout = document.createElement('div');
    callout.className = 'callout callout-info';
    callout.textContent =
        blessing.locale === 'zh_CN'
            ? 'Mojang 正版用户可直接登录，无需注册。'
            : 'You could log in using your Mojang account if you have paid for Minecraft.';
    (_a = document.querySelector('.login-card-body')) === null || _a === void 0 ? void 0 : _a.appendChild(callout);
});
