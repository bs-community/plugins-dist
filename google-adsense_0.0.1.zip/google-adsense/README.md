# google-adsense

A plugin for Blessing Skin Server that can let you display Google Ads with Google AdSense in the website.

## Usage

Enable this plugin.

Copy your client-id (ca-pub-xxxxxxxxxxxxxx) and save it in the settings of the plugin.

## License

MIT License

Copyright ©️ Big_Cake, All Rights Reserved.

[Google AdSense](https://www.google.com/adsense) is a registered trademark of Google LLC.

# Google AdSense（谷歌广告）

这个插件能让你在你的皮肤站内投放谷歌广告。

## 用法

启用该插件，并将你在 AdSense 页面获取的 client-id 填入配置页面。

保存，这时查看页面源代码，就可以看到谷歌广告的 script 标签了。

## 开源协议

MIT License

Copyright ©️ Big_Cake, All Rights Reserved.

[Google AdSense](https://www.google.com/adsense) 是 Google LLC 的注册商标。
