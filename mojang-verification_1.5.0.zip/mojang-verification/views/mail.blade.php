尊敬的 {{ $nickname }}：

我们很抱歉地告诉您，您的角色 {{ $playerName }} 已被转让给一个正版用户。
为此，我们向您补偿了 {{ option('score_per_player') }} 积分。

由此带来的不便，敬请谅解。

{{ option_localized('site_name') }}

-----------------------------------------------------------------------

Dear {{ $nickname }}:

We are sorry to tell you that your player {{ $playername }} has been transferred to another user who has paid for Minecraft.
Because of that, we have added {{ option('score_per_player') }} score to your account.

Sorry for the inconvenience.

{{ option_localized('site_name') }}
