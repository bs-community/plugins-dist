blessing.event.on('beforeFetch', (request) => {
    const search = new URLSearchParams(location.search);
    request.data.share = search.get('share') || '';
});
