'use strict'

console.info('示例：你只会在管理面板和皮肤库看到这行字')
