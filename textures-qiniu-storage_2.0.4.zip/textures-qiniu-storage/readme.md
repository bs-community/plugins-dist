请在皮肤站的 `.env` 配置文件中添加并填写以下条目：

```
# 你的七牛域名
QINIU_DOMAIN=
# 你的 HTTPS 域名（可不填）
QINIU_HTTPS_DOMAIN=
QINIU_ACCESS_KEY=
QINIU_SECRET_KEY=
QINIU_BUCKET=
# 空间访问控制，public 或 private
QINIU_BUCKET_ACCESS=public
```
