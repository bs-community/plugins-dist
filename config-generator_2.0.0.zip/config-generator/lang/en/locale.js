blessing.i18n.configGenerator = {
  csl13_1Upper: 'v13.1 and upper (recommended)',
  csl13_1Lower: 'lower than v13.1',
  usm1_4Upper: 'v1.4 and upper (recommended)',
  usm1_2To1_3: 'v1.2 to v1.3',
  usm1_2Lower: 'lower than v1.2'
}
