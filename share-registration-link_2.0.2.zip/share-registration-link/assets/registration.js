!function(e){"use strict";blessing.event.on("beforeFetch",e=>{const a=new URLSearchParams(location.search);e.data.share=a.get("share")||""})}();
