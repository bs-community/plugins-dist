'use strict'

console.warn('示例：使用 plugin_assets() 从插件目录下加载文件')
