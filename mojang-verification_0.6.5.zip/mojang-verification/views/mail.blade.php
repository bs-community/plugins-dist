尊敬的 {{ $nickname }}：

我们很抱歉地告诉您，您的角色 {{ $playerName }} 已被转让给一个正版用户。
为此，我们向您补偿了 {{ option('score_per_player') }} 积分。

由此带来的不便请谅解。

{{ option_localized('site_name') }}
