'use strict'

console.info('示例：使用 Hook::addScriptFileToPage() 加载插件目录下的文件到每个页面')

console.info("Javascript i18n example, calling trans('examplePlugin.test'): ")
console.log('Result: ' + trans('examplePlugin.test'))
