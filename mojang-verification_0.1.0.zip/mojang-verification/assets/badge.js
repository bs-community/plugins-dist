{
  const el = document.querySelector('.user-panel > .info')
  const badge = document.createElement('small')
  badge.className = 'label bg-purple'
  badge.textContent = '正版'
  el.appendChild(badge)
}
